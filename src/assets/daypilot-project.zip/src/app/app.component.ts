import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SchedulerComponent} from "./scheduler/scheduler.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, SchedulerComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
}
