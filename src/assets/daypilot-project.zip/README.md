# DayPilot UI Builder Project

This project was generated using [DayPilot UI Builder](https://builder.daypilot.org/).

## Versions

This project is based on [Angular CLI](https://github.com/angular/angular-cli) version 19.0.

This project includes [DayPilot Lite for JavaScript](https://javascript.daypilot.org/open-source/) (open-source).

## License

Apache License 2.0

## Project Initialization

Run `npm install` to download all dependencies.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.dev/tools/cli) page.
